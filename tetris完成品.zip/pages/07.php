<h2>
    左右移動の追加
</h2>
<div>
    <p>
        左右に移動するためのキーイベントを記述していきます。
    </p>

    <pre class="js"><code>

    // キーボードが押された時に呼び出される関数
    function keyPress( key ) {
        switch ( key ) {
            case 'left':
                if ( valid( -1 ) ) {
                --currentX;  // 左に一つずらす
                }
                break;
            case 'right':
                if ( valid( 1 ) ) {
                ++currentX;  // 右に一つずらす
                }
                break;
            case 'down':
                if ( valid( 0, 1 ) ) {
                ++currentY;  // 下に一つずらす
                }
                break;
        }
    }

    document.body.onkeydown = function( e ) {
        // キーに名前をセットする
        const keys = {
            37: 'left',
            39: 'right',
            40: 'down'
        }

        if ( typeof keys[ e.keyCode ] != 'undefined' ) {
            // セットされたキーの場合はkeyPressに記述された処理を呼び出す
            keyPress( keys[ e.keyCode ] );
            // 描画処理を行う
            render();
        }
    }

    </code></pre>
    
    <p>
        またvalid関数は下移動にしか対応していないので、左右に対応させます。
    </p>
    
    <pre class="js"><code>

    function valid( offsetX = 0, offsetY = 0, newCurrent = current ) {
        offsetX = currentX + offsetX;
        offsetY = currentY + offsetY;
        for ( let y = 0; y < 4; ++y ) {
            for ( let x = 0; x < 4; ++x ) {
                if ( newCurrent[ y ][ x ] ) {
                    if ( typeof board[ y + offsetY ] == 'undefined'
                        || typeof board[ y + offsetY ][ x + offsetX ] == 'undefined'
                        || board[ y + offsetY ][ x + offsetX ]
                        || x + offsetX < 0
                        || y + offsetY >= ROWS
                        || x + offsetX >= COLS ) {
                        return false;
                        }
                }
            }
        }
        return true;
    }

    </code></pre>
    
    <p>
        これで左右移動が実装できました。
    </p>

</div>