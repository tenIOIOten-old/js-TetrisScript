<h2>
    ゲームオーバーの処理、操作方法の表示
</h2>
<div>
    <p>
        最後にブロックが一番上まで積みあがった時の、ゲームオーバーの処理と、ユーザビリティのための操作方法を表示します。
    </p>
    <p>
        ゲームオーバーを識別するためのフラッグとして、lose変数を用意します。そして、valid関数の処理時に、ゲームオーバーかどうかの判定をし、tick関数でゲームオーバーであれば、ゲームを止めます。
    </p>

    <pre class="js"><code>

        let lose = false

        // newGameで指定した秒数毎に呼び出される関数。
        // 操作ブロックを下の方へ動かし、
        // 操作ブロックが着地したら消去処理、ゲームオーバー判定を行う
        function tick() {
            // １つ下へ移動する
            if ( valid( 0, 1 ) ) {
                ++currentY;
            }
            // もし着地していたら(１つしたにブロックがあったら)
            else {
                freeze();  // 操作ブロックを盤面へ固定する
                clearLines();  // ライン消去処理
                if (lose) {
                // もしゲームオーバならブロックを止める
                clearInterval(interval);
                return false;
                }
                // 新しい操作ブロックをセットする
                newShape();
            }
        }

        // 指定された方向に、操作ブロックを動かせるかどうかチェックする
        // ゲームオーバー判定もここで行う
        function valid( offsetX = 0, offsetY = 0, newCurrent = current) {
            offsetX = currentX + offsetX;
            offsetY = currentY + offsetY;
            for ( let y = 0; y < 4; ++y ) {
                for ( let x = 0; x < 4; ++x ) {
                    if ( newCurrent[ y ][ x ] ) {
                        if ( typeof board[ y + offsetY ] == 'undefined'
                            || typeof board[ y + offsetY ][ x + offsetX ] == 'undefined'
                            || board[ y + offsetY ][ x + offsetX ]
                            || x + offsetX < 0
                            || y + offsetY >= ROWS
                            || x + offsetX >= COLS ) {
                                if (offsetY == 1 &amp;&amp; offsetX-currentX == 0 &amp;&amp; offsetY-currentY == 1){
                                    console.log('game over');
                                    lose = true; // もし操作ブロックが盤面の上にあったらゲームオーバーにする
                                }
                            return false;
                            }
                    }
                }
            }
            return true;
        }

    </code></pre>

    <p>
        最後にhtmlに操作方法を記述して、終了です。スタイルはもう記述してあるので、問題なく表示できるはずです。
    </p>

    <pre class="html"><code>
        &lt;body>
            &lt;dl>
                &lt;dt>SpaceKey:&lt;/dt>&lt;dd>Start Game&lt;/dd>
                &lt;dt>UpKey:&lt;/dt>&lt;dd>Role Block&lt;/dd>
                &lt;dt>DownKey:&lt;/dt>&lt;dd>Down Block&lt;/dd>
                &lt;dt>LeftKey:&lt;/dt>&lt;dd>Move Block to Left&lt;/dd>
                &lt;dt>RightKey:&lt;/dt>&lt;dd>Move Block to Right&lt;/dd>
            &lt;/dl>
            .
            .
            .
            .
            .

    </code></pre>

</div>