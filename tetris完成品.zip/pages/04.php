<h2>
    ブロックを描画
</h2>
<div>
    <p>
        では今度はブロックを描画していきます。current,currentX,currentYで移動可能なブロックの情報を保持しています。
    </p>
    <p>
        newShape関数によりブロックのパターンを定義してある、shapesを使い新しい、ブロックを作成します。この時作成する配列は後にブロックを回転させるrotate関数を作成する際に必要となるため、４かける４の配列となっています。
    </p>
    
    <pre class="js"><code>
    const COLS = 10, ROWS = 20;  // 盤面のマスの数
    let board = [];  // 盤面の状態を保持する変数
    let current; // 現在操作しているブロック
    let currentX, currentY; // 現在操作しているブロックのいち
    let id = 0;//のちにランダムに生成
    // ブロックのパターン
    const shapes = [
    [ 1, 1, 1, 1 ]
    ];

    // shapesからランダムにブロックのパターンを出力し、盤面の一番上へセットする
    function newShape() {
        let shape = shapes[ id ];
        // パターンを操作ブロックへセットする
        current = [];
        for ( let y = 0; y < 4; ++y ) {
            current[ y ] = [];
            for ( let x = 0; x < 4; ++x ) {
            let i = 4 * y + x;
            if ( typeof shape[ i ] != 'undefined' &amp;&amp; shape[ i ] ) {
                current[ y ][ x ] = id + 1;
            }
            else {
                current[ y ][ x ] = 0;
            }
            }
        }
        // ブロックを盤面の上のほうにセットする
        currentX = 5;
        currentY = 0;
    }
    </code></pre>
    
    <p>
        次にその作成したブロックを描画するため、render関数を修正を加えます。。
    </p>

    <pre class="js"><code>
    // 盤面と操作ブロックを描画する
    function render() {
        let elTrs = document.getElementById('body').children
        for (let i = 0; i < elTrs.length; i++) {
            let elTds = elTrs.item(i).children
            for (let j = 0; j < elTds.length; j++) {
                let elTd = elTds.item(j) // tdタグそれぞれに対する処理
                elTd.classList.remove(
                    "tetrisI",
                    "default"
                ); // まずはクラスをすべてなしにする
                switch (board[i][j]) {
                    case 1:
                        elTd.classList.add("tetrisI"); // 数字の時にはクラスを割り振る
                        break;
                    default:
                        elTd.classList.add("default"); // それ以外の時にはdefaultクラスを割り振る
                }
                    //　currentの領域に来たらcurrentに描画処理をする
                if(4>i-currentY&amp;&amp;i-currentY>=0&amp;&amp;j-currentX>=0&amp;&amp;4>j-currentX){
                switch (current[i-currentY][j-currentX]) {
                    case 1:
                        elTd.classList.add("tetrisI"); 
                        break;
                }
                }
            }
        }
    }
    </code></pre>

    <p>
        そして一連の初期化の関数をまとめて呼び出すためnewGame関数を作成し、ファイルの最後で呼び出します。
    </p>

    <pre class="js"><code>
    function newGame() {
        init();  // 盤面をまっさらにする
        newShape();  // 新しいブロックをセットする
        render();
    }

    newGame();
    </code></pre>
    
</div>