<h2>
    ブロックを落とす、キーイベントの作成
</h2>
<div>
    <p>
        ブロックを落としていきます。currentの情報を更新するtick関数を作成します。
    </p>
    
    <pre class="js"><code>

    // newGameで指定した秒数毎に呼び出される関数。
    function tick() {
    // １つ下へ移動する
        ++currentY;
    }

    </code></pre>
    
    <p>
        そしてnewGame関数の中でtick関数を一定時間ごとに呼び出す記述をしていきます。また一定時間ごとに再描画し直す記述もします。これで自動で情報を更新し、再描画する記述ができました。
    </p>

    <pre class="js"><code>

    function newGame() {
        clearInterval(interval);  // ゲームタイマーをクリア
        init();  // 盤面をまっさらにする
        newShape();  // 新しいブロックをセットする
        interval = setInterval( tick, 750 );  // 750ミリ秒ごとにtickという関数を呼び出す
    }

    newGame();//ゲームスタート
    setInterval( render, 30 );//fps = 1000/30

    </code></pre>
    
    <p>
        ではキーイベントを設定していきます。まずは落とすイベントしか発生させないので、キーバインディングは下矢印のみです。
    </p>
    <p>
        また何が押されたかをkeyPress関数に渡し、switch文で押されたキーによって処理を変えます。
    </p>

    <pre class="js"><code>

    // キーボードが押された時に呼び出される関数
    function keyPress( key ) {
        switch ( key ) {
        case 'down':
            ++currentY;  // 下に一つずらす
            break;

        }
    }

    document.body.onkeydown = function( e ) {
        // キーに名前をセットする
        const keys = {
            40: 'down'
        };

        if ( typeof keys[ e.keyCode ] != 'undefined' ) {
            // セットされたキーの場合はkeyPressに記述された処理を呼び出す
            keyPress( keys[ e.keyCode ] );
            // 描画処理を行う
            render();
        }
    }
    </code></pre>

</div>