<h2>
    有効性の確認
</h2>
<div>
    <p>
        移動の際、currentの情報を更新する前に移動が有効かどうかをチェックする必要があります。なのでvalid関数を作成します。
    </p>

    <pre class="js"><code>

    // 指定された方向に、操作ブロックを動かせるかどうかチェックする
    function valid( offsetX = 0, offsetY = 0, newCurrent = current ) {
        offsetX = currentX + offsetX;
        offsetY = currentY + offsetY;
        for ( let y = 0; y < 4; ++y ) {
            for ( let x = 0; x < 4; ++x ) {
                if ( newCurrent[ y ][ x ] ) {
                    if ( typeof board[ y + offsetY ] == 'undefined'
                        || board[ y + offsetY ][ x + offsetX ]) {
                        return false;
                        }
                }
            }
        }
        return true;
    }
    
    </code></pre>
    <p>
        また操作ブロックが着地したら、操作ブロックをbord配列に落とす関数、freeze関数を作成します。
    </p>
    <pre class="js"><code>

    // 操作ブロックを盤面にセットする関数
    function freeze() {
        for ( let y = 0; y < 4; ++y ) {
            for ( let x = 0; x < 4; ++x ) {
                if ( current[ y ][ x ] ) {
                    board[ y + currentY ][ x + currentX ] = current[ y ][ x ];
                }
            }
        }
    }
    
    </code></pre>
    <p>
        これらの関数を作成できたら、これまでの記述をこれらの関数を含めた記述に修正していきます。
    </p>
    <pre class="js"><code>
    
    // newGameで指定した秒数毎に呼び出される関数。
    // 操作ブロックを下の方へ動かし、
    // 操作ブロックが着地したら消去処理、ゲームオーバー判定を行う
    function tick() {
        // １つ下へ移動する
        if ( valid( 0, 1 ) ) {
            ++currentY;
        }
        // もし着地していたら(１つしたにブロックがあったら)
        else {
            freeze();  // 操作ブロックを盤面へ固定する
            // 新しい操作ブロックをセットする
            newShape();
        }
    }



    // キーボードが押された時に呼び出される関数
    function keyPress( key ) {
        switch ( key ) {
            case 'down':
                if ( valid( 0, 1 ) ) {
                ++currentY;  // 下に一つずらす
                }
                break;
        }
    }
    </code></pre>
    <p>
        これで操作ブロックを着地させる判定と処理を実装できました。
    </p>
</div>