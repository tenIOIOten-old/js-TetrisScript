<h2>初期状態の描画</h2>
<div>
    <p>
        それではJavaScriptを記述していきます。まず盤面を１０かける２０の数のマス集合とするので。そのマスの情報を入れる配列を作成して初期化していきます。
    </p>
    <pre class="js"><code>
    const COLS = 10, ROWS = 20;  // 盤面のマスの数
    let board = [];  // 盤面の状態を保持する変数


    // 盤面を空にする
    function init() {
        for ( let y = 0; y < ROWS; ++y ) {
            board[ y ] = [];
            for ( let x = 0; x < COLS; ++x ) {
            board[ y ][ x ] = 0;
            }
        }
    }  
    </code></pre>
    <p>
        次にこの配列からマスの情報を得て、その情報からひとつひとつのマスにクラスを付加し、色を変える関数を作成していきます。
    </p>
    <p>
        またそれらの関数の宣言が終わったら呼び出して。表示してあげます。
    </p>
    <pre class="js"><code>
    // 盤面と操作ブロックを描画する
    function render() {
        let elTrs = document.getElementById('body').children
        for (let i = 0; i < elTrs.length; i++) {
            let elTds = elTrs.item(i).children
            for (let j = 0; j < elTds.length; j++) {
                let elTd = elTds.item(j) // tdタグそれぞれに対する処理
                elTd.classList.remove(
                    "default"
                ); // まずはクラスをすべてなしにする
                switch (board[i][j]) {
                    default:
                        elTd.classList.add("default"); // それ以外の時にはdefaultクラスを割り振る
                }
            }
        }
    }

    init();
    render();
    </code></pre>
</div>