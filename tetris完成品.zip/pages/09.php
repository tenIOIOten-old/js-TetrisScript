<h2>
    ラインを消す、ゲームスタートをキーイベントに追加
</h2>
<div>
    <p>
        ラインを消す判定をする関数を作成したいと思います。またその関数を、tick関数内で呼び出す記述をしたいと思います。
    </p>

    <pre class="js"><code>
        // newGameで指定した秒数毎に呼び出される関数。
        // 操作ブロックを下の方へ動かし、
        // 操作ブロックが着地したら消去処理、ゲームオーバー判定を行う
        function tick() {
            // １つ下へ移動する
            if ( valid( 0, 1 ) ) {
                ++currentY;
            }
            // もし着地していたら(１つしたにブロックがあったら)
            else {
                freeze();  // 操作ブロックを盤面へ固定する
                clearLines();  // ライン消去処理
                // 新しい操作ブロックをセットする
                newShape();
            }
        }
        .
        .
        .
        .
        .
        // 一行が揃っているか調べ、揃っていたらそれらを消す
        function clearLines() {
            for ( let y = ROWS - 1; y >= 0; --y ) {
                let rowFilled = true;
                // 一行が揃っているか調べる
                for ( let x = 0; x < COLS; ++x ) {
                    if ( board[ y ][ x ] == 0 ) {
                        rowFilled = false;
                        break;
                    }
                }
                // もし一行揃っていたら, それらを消す。
                if ( rowFilled ) {
                    // その上にあったブロックを一つずつ落としていく
                    for ( let yy = y; yy > 0; --yy ) {
                        for ( let x = 0; x < COLS; ++x ) {
                            board[ yy ][ x ] = board[ yy - 1 ][ x ];
                        }
                    }
                    ++y;  // 一行落としたのでチェック処理を一つ下へ送る
                }
            }
        }
    </code></pre>

    <p>
        次にゲームスタートをキーイベントで制御できるようにします。
        またframe変数を宣言して、setInterval関数の返り値を格納しています。こうすることで、レンダリング処理がスペースキーを押すたびに重複することがないようにしてあります。
    </p>

    <pre class="js"><code>

    let frame;

    // キーボードが押された時に呼び出される関数
    function keyPress( key ) {
        switch ( key ) {
            case 'left':
                if ( valid( -1 ) ) {
                --currentX;  // 左に一つずらす
                }
                break;
            case 'right':
                if ( valid( 1 ) ) {
                ++currentX;  // 右に一つずらす
                }
                break;
            case 'down':
                if ( valid( 0, 1 ) ) {
                ++currentY;  // 下に一つずらす
                }
                break;
            case 'rotate':
                // 操作ブロックを回す
                let rotated = rotate( current );
                if ( valid( 0, 0, rotated ) ) {
                current = rotated;  // 回せる場合は回したあとの状態に操作ブロックをセットする
                }
                break;
            case 'start':
                clearInterval(frame);
                newGame();
                frame = setInterval( render, 30 );
                break;
        }
    }

    document.body.onkeydown = function( e ) {
        // キーに名前をセットする
        const keys = {
            37: 'left',
            39: 'right',
            40: 'down',
            38: 'rotate',
            32: 'start'
        };

        if ( typeof keys[ e.keyCode ] != 'undefined' ) {
            // セットされたキーの場合はkeyPressに記述された処理を呼び出す
            keyPress( keys[ e.keyCode ] );
            // 描画処理を行う
            render();
        }
    }
    </code></pre>
    <p>
        これでラインを消す処理と、スタートのキーイベントを設定できました。
    </p>
</div>