<h2>
    回転の実装
</h2>
<div>
    <p>
        回転させる関数、rotate関数を作成します。この関数ではcurrentを回転させた新しい配列を作成し、呼び出し元に返しています。
    </p>

    <pre class="js"><code>

    // 操作ブロックを回す処理
    function rotate( current ) {
        let newCurrent = [];
        for ( let y = 0; y < 4; ++y ) {
            newCurrent[ y ] = [];
            for ( let x = 0; x < 4; ++x ) {
            newCurrent[ y ][ x ] = current[ 3 - x ][ y ];
            }
        }
        return newCurrent;
    }

    </code></pre>
    <p>
        ではこの関数をキーイベントに設定していきます。
    </p>

    <pre class="js"><code>
        // キーボードが押された時に呼び出される関数
    function keyPress( key ) {
        switch ( key ) {
            case 'left':
                if ( valid( -1 ) ) {
                --currentX;  // 左に一つずらす
                }
                break;
            case 'right':
                if ( valid( 1 ) ) {
                ++currentX;  // 右に一つずらす
                }
                break;
            case 'down':
                if ( valid( 0, 1 ) ) {
                ++currentY;  // 下に一つずらす
                }
                break;
            case 'rotate':
                // 操作ブロックを回す
                let rotated = rotate( current );
                if ( valid( 0, 0, rotated ) ) {
                current = rotated;  // 回せる場合は回したあとの状態に操作ブロックをセットする
                }
                break;
        }
    }

    document.body.onkeydown = function( e ) {
        // キーに名前をセットする
        const keys = {
            37: 'left',
            39: 'right',
            40: 'down',
            38: 'rotate',
        };

        if ( typeof keys[ e.keyCode ] != 'undefined' ) {
            // セットされたキーの場合はkeyPressに記述された処理を呼び出す
            keyPress( keys[ e.keyCode ] );
            // 描画処理を行う
            render();
        }
    };

    </code></pre>
    <p>
        これで回転の実装ができました。
    </p>
</div>