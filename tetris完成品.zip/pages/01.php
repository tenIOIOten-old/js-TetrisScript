<h2>
    何を作るのか
</h2>
<div>
    <p>
        今回はJavaScriptでテトリスを作成していきます。
        以下がデモページになります。
    </p>
    <p>
        <a href="./demo/" target="_blank">デモページ</a>
    </p>

</div>