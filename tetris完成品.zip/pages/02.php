<h2>htmlの記述</h2>
<div>
    <p>
        JavaScriptの勉強としてテトリスを学んでいくのでhtml、cssのほとんどの記述を終わらせておきます。
        以下のコードをそれぞれコピぺしておいてください。
    </p>

    <pre class="html">
    <code>
&lt;!DOCTYPE html>
&lt;html>
    &lt;head>
        &lt;meta charset="utf-8">
        &lt;title>テトリススクリプト&lt;/title>
        &lt;link rel="stylesheet" href="./css/style.css">
    &lt;/head>
    &lt;body>

        &lt;table id="game">
            &lt;tbody id = 'body'>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;tr>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;td>&lt;/td>&lt;/tr>
            &lt;/tbody>
        &lt;/table>  
        &lt;script src="./js/tetris.js" type="text/javascript">&lt;/script>
    &lt;/body>
&lt;/html>
    </code>
    </pre>

    <pre class="css">
    <code>
body {
    background-color: #263238;
}
dl{
    position:relative;
    right: 20%;
    color:white;
    float: right;
}
table {
    margin: auto; /* 中央寄せ */
    width: 400px;
    height: 750px;
}
td {
    width: 10%; /* 横10マス */
    height: 5%; /* 縦20マス */
}
.default {
    background-color: #455A64;
}
.tetrisI {
    background-color: #03A9F4;
}
.tetrisO{
    background-color: yellow;
}
.tetrisS{
    background-color: red;
}
.tetrisZ{
    background-color: green;
}
.tetrisL{
    background-color: blue;
}
.tetrisJ{
    background-color: greenyellow;
}
.tetrisT{
    background-color: purple;
}
    </code>
    </pre>
</div>